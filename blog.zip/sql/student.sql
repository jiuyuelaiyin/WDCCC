INSERT INTO `student` (`name`, `ID`, `sex`, `chinese`, `math`, `english`) VALUES ('龙致雨', 1, '女', 99, 99, 99);
INSERT INTO `student` (`name`, `ID`, `sex`, `chinese`, `math`, `english`) VALUES ('阿离', 2, '女', 99, 99, 99);
