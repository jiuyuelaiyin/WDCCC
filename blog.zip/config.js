// 数据库的信息
const DB = {
    host:"localhost",
    port:3306,
    user:"root",
    password:"123456",
    database:"blog"
};

module.exports = DB;
